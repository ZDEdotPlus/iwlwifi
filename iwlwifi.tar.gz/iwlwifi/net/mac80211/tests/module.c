// SPDX-License-Identifier: GPL-2.0-only
/*
 * This is just module boilerplate for the mac80211 kunit module.
 *
 * Copyright (C) 2023 Intel Corporation
 */
#include <linux/module.h>

MODULE_LICENSE("GPL");
